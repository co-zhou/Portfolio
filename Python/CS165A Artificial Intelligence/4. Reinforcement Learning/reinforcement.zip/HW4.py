import numpy as np
import matplotlib.pyplot as plt

rewards = np.array([[1, 0],
           [1, 0],
           [1, 10]])

transitions = np.array([[0, 1],
               [0, 2],
               [0, 2]])

def q2c(alpha, gamma, T):
    print("q2c:")
    Q = np.zeros((3,2))
    s = 0
    Value = np.zeros((T))
    for i in range(T):
        for a in range(2):
            Q[s][a] = Q[s][a] + alpha*(rewards[s][a]+gamma*max([Q[transitions[s][a]][j] for j in range(2)]) - Q[s][a])
        s = transitions[s][np.argmax(Q[s])]
        print("T =", i+1)
        print(Q)
        Value[i] = np.max(Q[0])
    Transition = np.zeros((3,3))#T.T e s'xs
    Reward = np.zeros((3))
    for s in range(3):
        action = np.argmax([Q[s][a] for a in range(2)])
        Transition[s][transitions[s][action]] = 1
        Reward[s] = rewards[s][action]
    return Transition, Reward, Value

def q2d(alpha, gamma, T, policyString):
    print("q2d:")
    Q = np.zeros((3,2))
    policy = [int(x) for x in list(policyString)]
    s = 0
    Value = np.zeros((T))
    for i in range(T):
        for a in range(2):
            Q[s][a] = Q[s][a] + alpha*(rewards[s][a]+gamma*max([Q[transitions[s][a]][j] for j in range(2)]) - Q[s][a])
        s = transitions[s][policy[i]]
        print("T =", i+1)
        print(Q)
        Value[i] = np.sum(Q[0])/2                
        
    return np.array([[0.5, 0.5, 0], [0.5, 0, 0.5], [0.5, 0, 0.5]]), np.array([0.5*np.sum(rewards[s]) for s in range(3)]), Value

def q2e(Transition, Reward, gamma):
    return np.linalg.solve(np.identity((Transition.shape[0])) - gamma*Transition.T, Reward)

def q2f(greedyV, randomV):
    x = np.arange(20)
    plt.plot(x, greedyV)
    plt.plot(x, randomV)
    plt.title("q2f")
    plt.xlabel("t")
    plt.ylabel("Policy Value")
    plt.show()

if __name__ == "__main__":
    greedy = q2c(0.5, 0.9, 20)
    random = q2d(0.5, 0.9, 20, "11111010100001100011")

    print("q2e:")
    print(q2e(greedy[0], greedy[1], 0.9))
    print(q2e(random[0], random[1], 0.9))

    print("q2f:")
    print(greedy[2][19])
    print(  random[2][19])
    q2f(greedy[2], random[2])

